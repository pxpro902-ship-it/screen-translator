package id.screentranslator

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.launch

private val TEXT_COLORS = listOf(0xFFFFFFFF, 0xFFFFEB3B, 0xFF000000, 0xFFA5D6A7, 0xFF80DEEA).map { it.toInt() }
private val BG_COLORS = listOf(0xFF000000, 0xFF0D1B4C, 0xFF37474F, 0xFFFFFFFF, 0xFF4A148C).map { it.toInt() }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val ctx = LocalContext.current
            val scheme = if (isSystemInDarkTheme()) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val settings = remember { AppSettings(ctx) }
    var page by remember { mutableStateOf("home") }
    if (page == "settings") {
        BackHandler { page = "home" }
        SettingsPage(settings) { page = "home" }
    } else {
        HomePage(settings) { page = "settings" }
    }
}

private fun accessibilityOn(ctx: Context): Boolean =
    Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?.contains(ScreenAccessibilityService::class.java.name) == true

@Composable
fun HomePage(settings: AppSettings, openSettings: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val running by CaptureService.running.collectAsState()
    val status by CaptureService.status.collectAsState()

    var mode by remember { mutableStateOf(settings.mode) }
    var source by remember { mutableStateOf(settings.sourceLang) }
    var tts by remember { mutableStateOf(settings.ttsEnabled) }
    var menu by remember { mutableStateOf(false) }
    var consentDialog by remember { mutableStateOf(false) }
    var overlayDialog by remember { mutableStateOf(false) }
    var overlayOk by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }
    var a11yOn by remember { mutableStateOf(accessibilityOn(ctx)) }
    var modelMsg by remember { mutableStateOf("") }
    var notifAsked by remember { mutableStateOf(false) }
    var kick by remember { mutableIntStateOf(0) }

    DisposableEffect(Unit) {
        val act = ctx as ComponentActivity
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                overlayOk = Settings.canDrawOverlays(ctx)
                a11yOn = accessibilityOn(ctx)
            }
        }
        act.lifecycle.addObserver(obs)
        onDispose { act.lifecycle.removeObserver(obs) }
    }

    val captureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == Activity.RESULT_OK && data != null) {
            val i = Intent(ctx, CaptureService::class.java)
                .setAction(CaptureService.ACTION_START)
                .putExtra(CaptureService.EXTRA_CODE, res.resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
            ContextCompat.startForegroundService(ctx, i)
            (ctx as Activity).moveTaskToBack(true)   // kembali ke aplikasi/game sebelumnya
        } else {
            Toast.makeText(ctx, "Izin tangkap layar ditolak", Toast.LENGTH_SHORT).show()
        }
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { kick++ }

    fun startFlow() {
        if (!settings.consent) { consentDialog = true; return }
        if (!Settings.canDrawOverlays(ctx)) { overlayDialog = true; return }
        if (Build.VERSION.SDK_INT >= 33 && !notifAsked &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifAsked = true
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        val mpm = ctx.getSystemService(MediaProjectionManager::class.java)
        captureLauncher.launch(mpm.createScreenCaptureIntent())
    }
    LaunchedEffect(kick) { if (kick > 0) startFlow() }

    fun openOverlaySettings() {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
    }

    Column(
        Modifier.fillMaxSize().safeDrawingPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Indonesia AI Screen Translator", style = MaterialTheme.typography.headlineSmall)
        Text("Terjemahkan teks di layar aplikasi atau game apa pun ke Bahasa Indonesia.")

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text(if (running) "● Penerjemahan aktif" else "○ Tidak aktif", style = MaterialTheme.typography.titleMedium)
                Text(status, style = MaterialTheme.typography.bodyMedium)
            }
        }

        Button(onClick = { startFlow() }, enabled = !running, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text("Mulai Terjemahkan")
        }
        OutlinedButton(
            onClick = { ctx.startService(Intent(ctx, CaptureService::class.java).setAction(CaptureService.ACTION_STOP)) },
            enabled = running, modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("Hentikan Terjemahan") }

        HorizontalDivider()

        Text("Bahasa sumber", style = MaterialTheme.typography.titleSmall)
        Box {
            OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) {
                Text(Languages.label(source) + "  ▾")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                Languages.source.forEach { (code, label) ->
                    DropdownMenuItem(text = { Text(label) }, onClick = {
                        source = code; settings.sourceLang = code; menu = false
                    })
                }
            }
        }
        Text("Bahasa tujuan: Indonesia", style = MaterialTheme.typography.bodyMedium)

        Text("Mode", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == Mode.GAME, onClick = { mode = Mode.GAME; settings.mode = Mode.GAME },
                label = { Text("Mode Game") })
            FilterChip(selected = mode == Mode.APP, onClick = { mode = Mode.APP; settings.mode = Mode.APP },
                label = { Text("Mode Aplikasi") })
        }
        Text(
            if (mode == Mode.GAME) "Ringan untuk game: resolusi tangkap kecil, pemindaian berkala, hanya saat layar berubah, hasil di-cache."
            else "Lebih akurat dan responsif untuk aplikasi, chat, dan web.",
            style = MaterialTheme.typography.bodySmall
        )

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("Suara terjemahan", style = MaterialTheme.typography.titleSmall)
                Text("Bacakan hasil terjemahan dengan suara Bahasa Indonesia.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = tts, onCheckedChange = { tts = it; settings.ttsEnabled = it })
        }

        OutlinedButton(onClick = openSettings, modifier = Modifier.fillMaxWidth()) { Text("Pengaturan Overlay & Suara") }

        OutlinedButton(onClick = {
            scope.launch {
                modelMsg = "Mengunduh model bahasa..."
                modelMsg = try { preloadModels(source); "Model siap. Terjemahan bisa dipakai offline." }
                catch (e: Exception) { "Gagal mengunduh. Periksa koneksi internet." }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Unduh model bahasa (offline)") }
        if (modelMsg.isNotEmpty()) Text(modelMsg, style = MaterialTheme.typography.bodySmall)

        HorizontalDivider()

        Text("Izin", style = MaterialTheme.typography.titleSmall)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Tampil di atas aplikasi lain: " + if (overlayOk) "diizinkan" else "belum diizinkan")
                Text("Untuk menampilkan tombol melayang dan teks terjemahan di atas aplikasi lain.", style = MaterialTheme.typography.bodySmall)
                if (!overlayOk) TextButton(onClick = { openOverlaySettings() }) { Text("Atur izin") }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Aksesibilitas (opsional): " + if (a11yOn) "aktif" else "tidak aktif")
                Text("Hanya memicu pemindaian ulang saat jendela berganti, layar bergulir, atau notifikasi muncul. Tidak membaca isi layar.", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Buka pengaturan Aksesibilitas") }
            }
        }
        Text(
            "Privasi: layar hanya diproses di HP ini lewat izin resmi Android. Gambar layar tidak direkam ke penyimpanan dan tidak dikirim ke mana pun. " +
                "Penerjemahan memakai ML Kit di perangkat. Anda bisa berhenti kapan saja lewat tombol di atas, notifikasi, atau tombol melayang.",
            style = MaterialTheme.typography.bodySmall
        )
    }

    if (consentDialog) {
        AlertDialog(
            onDismissRequest = { consentDialog = false },
            title = { Text("Izin yang dibutuhkan") },
            text = {
                Text(
                    "1. Tangkap layar (dialog resmi Android): agar teks di layar bisa dibaca. Pilih \"Seluruh layar\" bila Android menawarkan pilihan.\n\n" +
                        "2. Tampil di atas aplikasi lain: untuk tombol melayang dan hasil terjemahan.\n\n" +
                        "3. Notifikasi: menampilkan status dan tombol Berhenti.\n\n" +
                        "Layar tidak direkam atau dikirim tanpa persetujuan Anda. Terjemahan diproses di perangkat (kecuali Anda memilih server sendiri)."
                )
            },
            confirmButton = { TextButton(onClick = { settings.consent = true; consentDialog = false; startFlow() }) { Text("Saya mengerti, lanjut") } },
            dismissButton = { TextButton(onClick = { consentDialog = false }) { Text("Batal") } }
        )
    }
    if (overlayDialog) {
        AlertDialog(
            onDismissRequest = { overlayDialog = false },
            title = { Text("Izinkan tampil di atas aplikasi lain") },
            text = { Text("Aktifkan izin ini agar terjemahan bisa muncul di atas aplikasi atau game tanpa menutupnya. Setelah mengaktifkan, kembali ke sini lalu tekan Mulai Terjemahkan lagi.") },
            confirmButton = { TextButton(onClick = { overlayDialog = false; openOverlaySettings() }) { Text("Buka pengaturan") } },
            dismissButton = { TextButton(onClick = { overlayDialog = false }) { Text("Batal") } }
        )
    }
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = null)
        Text(label, Modifier.padding(start = 8.dp, top = 8.dp, bottom = 8.dp))
    }
}

@Composable
private fun ColorRow(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        colors.forEach { c ->
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(Color(c))
                    .border(if (c == selected) 3.dp else 1.dp, if (c == selected) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                    .clickable { onPick(c) }
            )
        }
    }
}

@Composable
fun SettingsPage(settings: AppSettings, back: () -> Unit) {
    var size by remember { mutableFloatStateOf(settings.textSizeSp) }
    var alpha by remember { mutableFloatStateOf(settings.bgAlpha.toFloat()) }
    var tc by remember { mutableIntStateOf(settings.textColor) }
    var bc by remember { mutableIntStateOf(settings.bgColor) }
    var pos by remember { mutableStateOf(settings.position) }
    var engine by remember { mutableStateOf(settings.engine) }
    var endpoint by remember { mutableStateOf(settings.endpoint) }
    var apiKey by remember { mutableStateOf(settings.apiKey) }
    val ctx = LocalContext.current
    var ttsOn by remember { mutableStateOf(settings.ttsEnabled) }
    var rate by remember { mutableFloatStateOf(settings.ttsRate) }
    var scope by remember { mutableStateOf(settings.ttsScope) }
    var voiceMsg by remember { mutableStateOf("") }
    val speaker = remember { Speaker(ctx, settings) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }

    Column(
        Modifier.fillMaxSize().safeDrawingPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        TextButton(onClick = back) { Text("← Kembali") }
        Text("Pengaturan Overlay", style = MaterialTheme.typography.headlineSmall)

        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.DarkGray).padding(16.dp)) {
            Text(
                "Contoh terjemahan: Selamat datang!", color = Color(tc), fontSize = size.sp,
                modifier = Modifier.background(Color(bc).copy(alpha = alpha / 100f)).padding(6.dp)
            )
        }

        Text("Posisi terjemahan", style = MaterialTheme.typography.titleSmall)
        RadioRow("Di atas teks asli", pos == Position.IN_PLACE) { pos = Position.IN_PLACE; settings.position = pos }
        RadioRow("Panel di atas layar", pos == Position.TOP) { pos = Position.TOP; settings.position = pos }
        RadioRow("Panel di bawah layar", pos == Position.BOTTOM) { pos = Position.BOTTOM; settings.position = pos }

        Text("Ukuran teks maksimum: ${size.toInt()} sp", style = MaterialTheme.typography.titleSmall)
        Slider(value = size, onValueChange = { size = it; settings.textSizeSp = it }, valueRange = 10f..28f)

        Text("Transparansi latar (kepekatan): ${alpha.toInt()}%", style = MaterialTheme.typography.titleSmall)
        Slider(value = alpha, onValueChange = { alpha = it; settings.bgAlpha = it.toInt() }, valueRange = 20f..100f)

        Text("Warna teks", style = MaterialTheme.typography.titleSmall)
        ColorRow(TEXT_COLORS, tc) { tc = it; settings.textColor = it }
        Text("Warna latar", style = MaterialTheme.typography.titleSmall)
        ColorRow(BG_COLORS, bc) { bc = it; settings.bgColor = it }

        OutlinedButton(onClick = { settings.fabX = 0; settings.fabY = 300 }, modifier = Modifier.fillMaxWidth()) {
            Text("Atur ulang posisi tombol melayang")
        }
        Text("Posisi tombol melayang diubah dengan menyeretnya langsung di layar.", style = MaterialTheme.typography.bodySmall)

        HorizontalDivider()

        Text("Suara terjemahan", style = MaterialTheme.typography.titleSmall)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Bacakan terjemahan", Modifier.weight(1f))
            Switch(checked = ttsOn, onCheckedChange = { ttsOn = it; settings.ttsEnabled = it })
        }
        Text("Kecepatan suara: ${"%.1f".format(rate)}x", style = MaterialTheme.typography.titleSmall)
        Slider(value = rate, onValueChange = { rate = it; settings.ttsRate = it }, valueRange = 0.6f..2.0f)
        Text("Yang dibacakan", style = MaterialTheme.typography.titleSmall)
        RadioRow("Semua teks yang baru muncul", scope == TtsScope.NEW) { scope = TtsScope.NEW; settings.ttsScope = scope }
        RadioRow("Hanya teks terpanjang yang baru (cocok untuk dialog game)", scope == TtsScope.LONGEST) { scope = TtsScope.LONGEST; settings.ttsScope = scope }
        OutlinedButton(onClick = {
            val problem = speaker.problem
            if (problem != null) voiceMsg = problem
            else { voiceMsg = ""; speaker.speak("Halo, ini contoh suara terjemahan.") }
        }, modifier = Modifier.fillMaxWidth()) { Text("Tes suara") }
        if (voiceMsg.isNotEmpty()) Text(voiceMsg, style = MaterialTheme.typography.bodySmall)

        HorizontalDivider()

        Text("Mesin terjemahan", style = MaterialTheme.typography.titleSmall)
        RadioRow("Offline di perangkat (ML Kit) – disarankan", engine == Engine.MLKIT) { engine = Engine.MLKIT; settings.engine = engine }
        RadioRow("Server LibreTranslate sendiri (HTTPS)", engine == Engine.LIBRE) { engine = Engine.LIBRE; settings.engine = engine }
        if (engine == Engine.LIBRE) {
            Text("Peringatan: teks hasil OCR (bukan gambar layar) akan dikirim ke server yang Anda isi di bawah.", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(value = endpoint, onValueChange = { endpoint = it; settings.endpoint = it },
                label = { Text("Alamat server, mis. https://contoh.id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = apiKey, onValueChange = { apiKey = it; settings.apiKey = it },
                label = { Text("API key (opsional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
    }
}
