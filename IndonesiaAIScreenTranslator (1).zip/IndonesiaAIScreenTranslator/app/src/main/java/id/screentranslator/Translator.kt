package id.screentranslator

import android.util.LruCache
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Antarmuka mesin terjemahan. Untuk mengganti mesin (DeepL, Google Cloud, server sendiri, dsb.)
 * cukup buat kelas baru yang mengimplementasikan TextTranslator lalu pilih di TranslationPipeline.translator().
 */
interface TextTranslator {
    suspend fun translate(text: String, source: String, target: String): String
    fun close() {}
}

/** Default: ML Kit On-Device Translation. Teks diterjemahkan di HP; hanya model bahasa yang diunduh (sekali). */
class MlKitTextTranslator : TextTranslator {
    private val clients = ConcurrentHashMap<String, Translator>()
    private val ready = ConcurrentHashMap.newKeySet<String>()

    private fun client(s: String, t: String): Translator = clients.getOrPut("$s>$t") {
        val src = TranslateLanguage.fromLanguageTag(s) ?: error("Bahasa tidak didukung: $s")
        val dst = TranslateLanguage.fromLanguageTag(t) ?: error("Bahasa tidak didukung: $t")
        Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build())
    }

    suspend fun ensureModel(s: String, t: String) {
        val key = "$s>$t"
        if (ready.contains(key)) return
        client(s, t).downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
        ready.add(key)
    }

    override suspend fun translate(text: String, source: String, target: String): String {
        ensureModel(source, target)
        return client(source, target).translate(text).await()
    }

    override fun close() {
        clients.values.forEach { runCatching { it.close() } }
        clients.clear(); ready.clear()
    }
}

/** Opsional: server kompatibel LibreTranslate milik sendiri (HTTPS). Hanya TEKS yang dikirim, bukan gambar layar. */
class LibreTranslator(val endpoint: String, val apiKey: String) : TextTranslator {
    override suspend fun translate(text: String, source: String, target: String): String =
        withContext(Dispatchers.IO) {
            if (endpoint.isBlank()) error("Alamat server terjemahan belum diisi (Pengaturan Overlay).")
            val conn = (URL(endpoint.trimEnd('/') + "/translate").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 8000; readTimeout = 12000; doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            try {
                val body = JSONObject().put("q", text).put("source", source).put("target", target).put("format", "text")
                if (apiKey.isNotBlank()) body.put("api_key", apiKey)
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = conn.responseCode
                if (code !in 200..299) error("Server terjemahan menjawab HTTP $code")
                JSONObject(conn.inputStream.bufferedReader().use { it.readText() }).getString("translatedText")
            } finally {
                conn.disconnect()
            }
        }
}

/** Cache terjemahan: teks yang sama tidak diterjemahkan ulang. */
class TranslationCache(max: Int = 800) {
    private val lru = LruCache<String, String>(max)
    fun get(key: String): String? = lru.get(key)
    fun put(key: String, value: String) { lru.put(key, value) }
    fun clear() = lru.evictAll()
}

/** Unduh model terjemahan agar bisa dipakai offline. */
suspend fun preloadModels(source: String) {
    val t = MlKitTextTranslator()
    try {
        val list = if (source == "auto") listOf("en", "ja", "zh", "ko") else listOf(source)
        list.forEach { t.ensureModel(it, "id") }
    } finally {
        t.close()
    }
}
