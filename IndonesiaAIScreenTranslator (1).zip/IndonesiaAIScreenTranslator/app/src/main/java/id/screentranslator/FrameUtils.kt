package id.screentranslator

import android.graphics.Bitmap
import android.media.Image
import kotlin.math.abs

object FrameUtils {
    private const val COLS = 64
    private const val ROWS = 128

    /** Tanda tangan ringan layar (grid 64x128 piksel terambil) untuk mendeteksi perubahan tanpa menyalin seluruh frame. */
    fun signature(image: Image): ByteArray {
        val plane = image.planes[0]
        val buf = plane.buffer
        val rs = plane.rowStride
        val ps = plane.pixelStride
        val w = image.width
        val h = image.height
        val out = ByteArray(COLS * ROWS)
        for (r in 0 until ROWS) {
            val y = (r * h) / ROWS + h / (ROWS * 2)
            for (c in 0 until COLS) {
                val x = (c * w) / COLS + w / (COLS * 2)
                val i = y * rs + x * ps
                val lum = ((buf.get(i).toInt() and 0xFF) * 3 +
                        (buf.get(i + 1).toInt() and 0xFF) * 6 +
                        (buf.get(i + 2).toInt() and 0xFF)) / 10
                out[r * COLS + c] = lum.toByte()
            }
        }
        return out
    }

    /** Rasio sel grid yang berubah cukup besar (0..1). */
    fun changedRatio(a: ByteArray, b: ByteArray, tolerance: Int = 28): Float {
        var n = 0
        for (i in a.indices) {
            if (abs((a[i].toInt() and 0xFF) - (b[i].toInt() and 0xFF)) > tolerance) n++
        }
        return n.toFloat() / a.size
    }

    fun toBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pad = plane.rowStride - plane.pixelStride * image.width
        val full = Bitmap.createBitmap(image.width + pad / plane.pixelStride, image.height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(plane.buffer)
        if (pad == 0) return full
        val cropped = Bitmap.createBitmap(full, 0, 0, image.width, image.height)
        full.recycle()
        return cropped
    }
}
