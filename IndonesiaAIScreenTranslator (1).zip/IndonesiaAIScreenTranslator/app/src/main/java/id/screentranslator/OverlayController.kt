package id.screentranslator

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as WLP
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max

/** Semua method harus dipanggil dari main thread. */
class OverlayController(
    private val ctx: Context,
    private val settings: AppSettings,
    private val onToggle: () -> Unit,
    private val onOpenApp: () -> Unit
) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val dm = ctx.resources.displayMetrics
    private val dp = dm.density
    private var layer: FrameLayout? = null
    private var fab: TextView? = null

    @Volatile var hasContent = false
        private set

    fun show() {
        val l = FrameLayout(ctx)
        val lp = WLP(
            WLP.MATCH_PARENT, WLP.MATCH_PARENT, WLP.TYPE_APPLICATION_OVERLAY,
            WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCHABLE or WLP.FLAG_LAYOUT_IN_SCREEN or WLP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            layoutInDisplayCutoutMode = WLP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        wm.addView(l, lp)
        layer = l
        addFab()
    }

    fun hide() {
        layer?.let { runCatching { wm.removeView(it) } }
        fab?.let { runCatching { wm.removeView(it) } }
        layer = null; fab = null; hasContent = false
    }

    private fun addFab() {
        val size = (52 * dp).toInt()
        val tv = TextView(ctx).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
        }
        val lp = WLP(
            size, size, WLP.TYPE_APPLICATION_OVERLAY,
            WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = settings.fabX; y = settings.fabY
        }
        tv.setOnTouchListener(DragListener(lp))
        wm.addView(tv, lp)
        fab = tv
        setEnabledVisual(settings.enabled)
    }

    fun setEnabledVisual(on: Boolean) {
        fab?.apply {
            text = if (on) "ON" else "OFF"
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (on) 0xE62E7D32.toInt() else 0xE6616161.toInt())
            }
        }
    }

    /** Sembunyikan lapisan terjemahan sesaat agar OCR tidak membaca terjemahannya sendiri. */
    fun setLayerVisible(visible: Boolean) { layer?.alpha = if (visible) 1f else 0f }

    fun clear() { layer?.removeAllViews(); hasContent = false }

    fun render(items: List<TranslatedItem>) {
        val l = layer ?: return
        l.removeAllViews()
        hasContent = items.isNotEmpty()
        if (items.isEmpty()) return

        val bounds = wm.maximumWindowMetrics.bounds
        val bg = withAlpha(settings.bgColor, settings.bgAlpha)
        val fg = settings.textColor
        val sp = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 1f, dm)
        val maxPx = settings.textSizeSp * sp
        val pad = (4 * dp).toInt()

        if (settings.position == Position.IN_PLACE) {
            for (item in items) {
                val r = item.rect
                val perLine = r.height() / item.lineCount.toFloat()
                val px = (perLine * 0.6f).coerceIn(10 * sp, maxPx)
                val w = max(r.width() + 2 * pad, (120 * dp).toInt()).coerceAtMost(bounds.width())
                val tv = TextView(ctx).apply {
                    text = item.translated
                    setTextColor(fg)
                    setBackgroundColor(bg)
                    setTextSize(TypedValue.COMPLEX_UNIT_PX, px)
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(pad, pad / 2, pad, pad / 2)
                    minHeight = r.height()
                }
                val lp = FrameLayout.LayoutParams(w, FrameLayout.LayoutParams.WRAP_CONTENT)
                lp.leftMargin = (r.left - pad).coerceIn(0, max(0, bounds.width() - w))
                lp.topMargin = r.top.coerceAtLeast(0)
                l.addView(tv, lp)
            }
        } else {
            val top = settings.position == Position.TOP
            val tv = TextView(ctx).apply {
                text = items.joinToString("\n\n") { it.translated }
                setTextColor(fg)
                setBackgroundColor(bg)
                setTextSize(TypedValue.COMPLEX_UNIT_PX, maxPx)
                setPadding(pad * 4, pad * 3, pad * 4, pad * 3)
                maxLines = 14
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            val lp = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                if (top) Gravity.TOP else Gravity.BOTTOM
            )
            if (top) lp.topMargin = (40 * dp).toInt() else lp.bottomMargin = (56 * dp).toInt()
            l.addView(tv, lp)
        }
        l.alpha = 1f
    }

    private fun withAlpha(color: Int, percent: Int): Int =
        Color.argb(percent.coerceIn(0, 100) * 255 / 100, Color.red(color), Color.green(color), Color.blue(color))

    /** Seret = pindah; ketuk = ON/OFF; tekan lama = buka aplikasi. */
    private inner class DragListener(private val lp: WLP) : View.OnTouchListener {
        private var sx = 0; private var sy = 0
        private var tx = 0f; private var ty = 0f
        private var moved = false
        private var downAt = 0L

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY
                    moved = false; downAt = SystemClock.uptimeMillis()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = (sx + dx).coerceAtLeast(0); lp.y = (sy + dy).coerceAtLeast(0)
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) { settings.fabX = lp.x; settings.fabY = lp.y }
                    else if (SystemClock.uptimeMillis() - downAt > 600) onOpenApp()
                    else onToggle()
                }
            }
            return true
        }
    }
}
