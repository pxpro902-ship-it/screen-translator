package id.screentranslator

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Opsional. Hanya memberi sinyal "layar mungkin berubah" (jendela baru, scroll, notifikasi)
 * agar pemindaian dilakukan lebih cepat. Tidak membaca isi layar (canRetrieveWindowContent=false).
 */
class ScreenAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (CaptureService.running.value) CaptureService.requestRescan()
    }

    override fun onInterrupt() {}
}
