package id.screentranslator

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.common.MlKitException
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await

data class TranslatedItem(val original: String, val translated: String, val rect: Rect, val lineCount: Int)

/** Bitmap -> OCR -> deteksi bahasa -> (cache | terjemahan) -> daftar teks terjemahan. */
class TranslationPipeline(private val settings: AppSettings) {
    private val ocr = OcrEngine()
    private val langId = LanguageIdentification.getClient()
    private val cache = TranslationCache()
    private val mlkit = MlKitTextTranslator()
    private var libre: LibreTranslator? = null

    @Volatile var lastError: String? = null
        private set

    suspend fun process(bmp: Bitmap, maxBlocks: Int): List<TranslatedItem> {
        lastError = null
        val src = settings.sourceLang
        val blocks = ocr.recognize(bmp, Languages.scriptFor(src))
            .filter { b -> b.text.any { it.isLetter() } && b.text.trim().length >= 2 }
            .sortedBy { it.rect.top }
            .take(maxBlocks)

        val out = ArrayList<TranslatedItem>()
        for (b in blocks) {
            val text = b.text.replace(Regex("\\s+"), " ").trim()
            val from = if (src == "auto") detect(text) else src
            if (from == "id") continue

            val key = "${settings.engine.name}|$from|$text"
            var tr = cache.get(key)
            if (tr == null) {
                tr = try {
                    translator().translate(text, from, "id")
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    lastError = friendly(e)
                    null
                }
                if (tr != null) cache.put(key, tr)
            }
            if (tr == null && lastError != null) break   // jangan ulangi kegagalan untuk tiap blok
            if (!tr.isNullOrBlank() && !tr.equals(text, ignoreCase = true)) {
                out.add(TranslatedItem(text, tr, b.rect, b.lineCount))
            }
        }
        return out
    }

    private suspend fun detect(text: String): String {
        var kana = 0; var hangul = 0; var han = 0; var deva = 0
        for (ch in text) {
            when (Character.UnicodeScript.of(ch.code)) {
                Character.UnicodeScript.HIRAGANA, Character.UnicodeScript.KATAKANA -> kana++
                Character.UnicodeScript.HANGUL -> hangul++
                Character.UnicodeScript.HAN -> han++
                Character.UnicodeScript.DEVANAGARI -> deva++
                else -> {}
            }
        }
        return when {
            kana > 0 -> "ja"
            hangul > 0 -> "ko"
            deva > 0 -> "hi"
            han > 0 -> "zh"
            text.length < 8 -> "en"
            else -> {
                val tag = try {
                    langId.identifyLanguage(text).await()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    "und"
                }
                val base = tag.substringBefore('-')
                if (tag == "und" || tag.contains("Latn") || TranslateLanguage.fromLanguageTag(base) == null) "en" else base
            }
        }
    }

    private fun translator(): TextTranslator = when (settings.engine) {
        Engine.LIBRE -> {
            val e = settings.endpoint.trim()
            val k = settings.apiKey.trim()
            val cur = libre
            if (cur != null && cur.endpoint == e && cur.apiKey == k) cur else LibreTranslator(e, k).also { libre = it }
        }
        Engine.MLKIT -> mlkit
    }

    private fun friendly(e: Exception): String =
        if (e is MlKitException) "Model bahasa belum terunduh. Nyalakan internet sekali untuk mengunduhnya."
        else "Terjemahan gagal: ${e.message ?: e.javaClass.simpleName}"

    fun close() {
        ocr.close(); mlkit.close()
        runCatching { langId.close() }
    }
}
