package id.screentranslator

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Membacakan hasil terjemahan dengan suara Bahasa Indonesia (mesin TTS bawaan HP, offline bila suara terpasang). */
class Speaker(context: Context, private val settings: AppSettings) {
    private val am = context.getSystemService(AudioManager::class.java)
    private var tts: TextToSpeech? = null
    private var focus: AudioFocusRequest? = null
    private var last: Set<String> = emptySet()
    private var pending: String? = null

    @Volatile private var ready = false
    @Volatile var problem: String? = null
        private set

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            val t = tts
            if (status != TextToSpeech.SUCCESS || t == null) {
                problem = "Mesin suara (Text-to-Speech) tidak tersedia di HP ini."
            } else {
                val r = t.setLanguage(Locale("id", "ID"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    problem = "Suara Bahasa Indonesia belum terpasang. Buka Pengaturan > Output teks-ke-suara, pilih Google, lalu unduh data suara Indonesia."
                } else {
                    t.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) { abandonFocus() }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { abandonFocus() }
                        override fun onStop(utteranceId: String?, interrupted: Boolean) { abandonFocus() }
                    })
                    ready = true
                    pending?.let { pending = null; speak(it) }
                }
            }
        }
    }

    fun speak(text: String) {
        if (!ready) { pending = text; return }
        val t = tts ?: return
        t.setSpeechRate(settings.ttsRate.coerceIn(0.5f, 2.5f))
        requestFocus()
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tr-" + SystemClock.uptimeMillis())
    }

    /** Hanya membacakan teks yang baru muncul (tidak mengulang teks yang sama tiap pemindaian). */
    fun speakNew(items: List<TranslatedItem>) {
        val texts = items.sortedBy { it.rect.top }.map { it.translated }
        val fresh = texts.filter { it !in last }
        last = texts.toSet()
        if (fresh.isEmpty()) return
        val line = when (settings.ttsScope) {
            TtsScope.LONGEST -> fresh.maxByOrNull { it.length } ?: return
            TtsScope.NEW -> fresh.joinToString(". ")
        }
        speak(line.take(500))
    }

    fun stop() { tts?.stop(); abandonFocus() }

    fun shutdown() {
        runCatching { tts?.stop(); tts?.shutdown() }
        abandonFocus()
        tts = null; ready = false
    }

    private fun requestFocus() {
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            ).build()
        focus = req
        am.requestAudioFocus(req)
    }

    private fun abandonFocus() {
        focus?.let { am.abandonAudioFocusRequest(it) }
        focus = null
    }
}
