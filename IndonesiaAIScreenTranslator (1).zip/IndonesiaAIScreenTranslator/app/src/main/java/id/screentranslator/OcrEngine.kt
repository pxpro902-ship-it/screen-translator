package id.screentranslator

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import java.lang.Character.UnicodeScript

data class OcrBlock(val text: String, val rect: Rect, val lineCount: Int)

/** OCR on-device (ML Kit). Mode OTOMATIS mencoba Latin dulu, lalu aksara lain bila perlu. */
class OcrEngine {
    private val clients = HashMap<OcrScript, TextRecognizer>()
    private var autoMisses = 0
    private var lastAuto = OcrScript.LATIN

    @Synchronized
    private fun client(s: OcrScript): TextRecognizer = clients.getOrPut(s) {
        when (s) {
            OcrScript.CHINESE -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            OcrScript.JAPANESE -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
            OcrScript.KOREAN -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            OcrScript.DEVANAGARI -> TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
            else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        }
    }

    suspend fun recognize(bmp: Bitmap, script: OcrScript): List<OcrBlock> = when (script) {
        OcrScript.AUTO -> auto(bmp)
        OcrScript.LATIN -> latin(bmp)
        else -> runScript(script, bmp)
    }

    private suspend fun raw(s: OcrScript, bmp: Bitmap): List<OcrBlock> {
        val r = client(s).process(InputImage.fromBitmap(bmp, 0)).await()
        return r.textBlocks.mapNotNull { b ->
            b.boundingBox?.let { OcrBlock(b.text, it, b.lines.size.coerceAtLeast(1)) }
        }
    }

    private suspend fun latin(bmp: Bitmap) = raw(OcrScript.LATIN, bmp).filter { latinRatio(it.text) >= 0.6f }

    private suspend fun runScript(s: OcrScript, bmp: Bitmap): List<OcrBlock> = when (s) {
        OcrScript.JAPANESE -> {
            val ja = raw(s, bmp).filter { count(it.text, UnicodeScript.HIRAGANA, UnicodeScript.KATAKANA, UnicodeScript.HAN) > 0 }
            val hasKana = ja.any { count(it.text, UnicodeScript.HIRAGANA, UnicodeScript.KATAKANA) > 0 }
            if (ja.isNotEmpty() && !hasKana) runScript(OcrScript.CHINESE, bmp).ifEmpty { ja } else ja
        }
        OcrScript.CHINESE -> raw(s, bmp).filter { count(it.text, UnicodeScript.HAN) > 0 }
        OcrScript.KOREAN -> raw(s, bmp).filter { count(it.text, UnicodeScript.HANGUL) > 0 }
        OcrScript.DEVANAGARI -> raw(s, bmp).filter { count(it.text, UnicodeScript.DEVANAGARI) > 0 }
        else -> emptyList()
    }

    private suspend fun auto(bmp: Bitmap): List<OcrBlock> {
        val lat = latin(bmp)
        val letters = lat.sumOf { b -> b.text.count { it in 'A'..'Z' || it in 'a'..'z' } }
        if (letters >= 12) { autoMisses = 0; return lat }

        // Hemat baterai: sapuan penuh semua aksara hanya tiap 4 pemindaian bila layar kosong.
        val full = autoMisses % 4 == 0
        val tries = if (full) {
            listOf(lastAuto, OcrScript.JAPANESE, OcrScript.KOREAN, OcrScript.DEVANAGARI)
                .distinct().filter { it != OcrScript.LATIN }
        } else listOfNotNull(lastAuto.takeIf { it != OcrScript.LATIN })

        for (s in tries) {
            val r = runScript(s, bmp)
            if (r.isNotEmpty()) { lastAuto = s; autoMisses = 0; return r }
        }
        autoMisses++
        return lat
    }

    @Synchronized
    fun close() {
        clients.values.forEach { runCatching { it.close() } }
        clients.clear()
    }

    private fun count(text: String, vararg scripts: UnicodeScript): Int =
        text.count { UnicodeScript.of(it.code) in scripts }

    private fun latinRatio(text: String): Float {
        val nonSpace = text.count { !it.isWhitespace() }
        if (nonSpace == 0) return 0f
        val latin = text.count { it in 'A'..'Z' || it in 'a'..'z' || it in '\u00C0'..'\u00FF' }
        return latin.toFloat() / nonSpace
    }
}
