package id.screentranslator

import android.content.Context
import android.graphics.Color

enum class Mode { GAME, APP }
enum class Position { IN_PLACE, TOP, BOTTOM }
enum class Engine { MLKIT, LIBRE }
enum class TtsScope { NEW, LONGEST }
enum class OcrScript { AUTO, LATIN, CHINESE, JAPANESE, KOREAN, DEVANAGARI }

object Languages {
    /** Bahasa sumber yang bisa dibaca OCR ML Kit (aksara Latin, Mandarin, Jepang, Korea, Devanagari). */
    val source = listOf(
        "auto" to "Otomatis", "en" to "Inggris", "ja" to "Jepang", "zh" to "Mandarin",
        "ko" to "Korea", "es" to "Spanyol", "fr" to "Prancis", "de" to "Jerman",
        "pt" to "Portugis", "it" to "Italia", "hi" to "Hindi"
    )

    fun label(code: String) = source.firstOrNull { it.first == code }?.second ?: code

    fun scriptFor(code: String): OcrScript = when (code) {
        "auto" -> OcrScript.AUTO
        "zh" -> OcrScript.CHINESE
        "ja" -> OcrScript.JAPANESE
        "ko" -> OcrScript.KOREAN
        "hi" -> OcrScript.DEVANAGARI
        else -> OcrScript.LATIN
    }
}

class AppSettings(context: Context) {
    private val p = context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private inline fun <reified E : Enum<E>> enumOf(key: String, def: E): E =
        runCatching { enumValueOf<E>(p.getString(key, null) ?: "") }.getOrDefault(def)

    var consent: Boolean
        get() = p.getBoolean("consent", false)
        set(v) { p.edit().putBoolean("consent", v).apply() }

    var enabled: Boolean
        get() = p.getBoolean("enabled", true)
        set(v) { p.edit().putBoolean("enabled", v).apply() }

    var mode: Mode
        get() = enumOf("mode", Mode.APP)
        set(v) { p.edit().putString("mode", v.name).apply() }

    var position: Position
        get() = enumOf("position", Position.IN_PLACE)
        set(v) { p.edit().putString("position", v.name).apply() }

    var engine: Engine
        get() = enumOf("engine", Engine.MLKIT)
        set(v) { p.edit().putString("engine", v.name).apply() }

    var sourceLang: String
        get() = p.getString("source", "auto") ?: "auto"
        set(v) { p.edit().putString("source", v).apply() }

    var textSizeSp: Float
        get() = p.getFloat("textSize", 15f)
        set(v) { p.edit().putFloat("textSize", v).apply() }

    var textColor: Int
        get() = p.getInt("textColor", Color.WHITE)
        set(v) { p.edit().putInt("textColor", v).apply() }

    var bgColor: Int
        get() = p.getInt("bgColor", Color.BLACK)
        set(v) { p.edit().putInt("bgColor", v).apply() }

    /** 20..100 (persen) */
    var bgAlpha: Int
        get() = p.getInt("bgAlpha", 85)
        set(v) { p.edit().putInt("bgAlpha", v).apply() }

    var endpoint: String
        get() = p.getString("endpoint", "") ?: ""
        set(v) { p.edit().putString("endpoint", v).apply() }

    var apiKey: String
        get() = p.getString("apiKey", "") ?: ""
        set(v) { p.edit().putString("apiKey", v).apply() }

    /** Suara penerjemah (text-to-speech Bahasa Indonesia) */
    var ttsEnabled: Boolean
        get() = p.getBoolean("ttsEnabled", false)
        set(v) { p.edit().putBoolean("ttsEnabled", v).apply() }

    /** 0.6 .. 2.0 */
    var ttsRate: Float
        get() = p.getFloat("ttsRate", 1.0f)
        set(v) { p.edit().putFloat("ttsRate", v).apply() }

    var ttsScope: TtsScope
        get() = enumOf("ttsScope", TtsScope.NEW)
        set(v) { p.edit().putString("ttsScope", v.name).apply() }

    var fabX: Int
        get() = p.getInt("fabX", 0)
        set(v) { p.edit().putInt("fabX", v).apply() }

    var fabY: Int
        get() = p.getInt("fabY", 300)
        set(v) { p.edit().putInt("fabY", v).apply() }
}
