# Indonesia AI Screen Translator

Aplikasi Android (Kotlin + Jetpack Compose) yang menerjemahkan teks di layar aplikasi/game lain ke Bahasa Indonesia secara otomatis. OCR dan terjemahan berjalan di perangkat (ML Kit).

- Android 14+ (minSdk 34, targetSdk 35), termasuk POCO X7 Pro (Android 16)
- Alur: MediaProjection (tangkap layar) → deteksi perubahan layar → ML Kit OCR → deteksi bahasa → terjemahan (dengan cache) → overlay

## 1. Membuat APK

Persyaratan: Android Studio terbaru (Ladybug 2024.2.1 atau lebih baru), JDK 17 (sudah termasuk di Android Studio), koneksi internet untuk sinkronisasi Gradle pertama kali.

1. Ekstrak ZIP, lalu di Android Studio pilih **File → Open** dan buka folder `IndonesiaAIScreenTranslator`.
2. Tunggu **Gradle Sync** selesai. Bila diminta memasang Android SDK 35, setujui.
3. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

Lewat terminal (opsional): jalankan `gradle wrapper --gradle-version 8.9` sekali di folder proyek (butuh Gradle terpasang), lalu `./gradlew assembleDebug`. Untuk APK release yang ditandatangani kunci debug: `./gradlew assembleRelease`.

Catatan: berkas `gradlew` dan `gradle-wrapper.jar` tidak disertakan; Android Studio tidak membutuhkannya.

## 2. Memasang di HP

- Kabel USB: aktifkan **Opsi pengembang → Debugging USB**, lalu `adb install -r app-debug.apk`, atau tekan **Run ▶** di Android Studio.
- Tanpa kabel: salin APK ke HP, buka lewat File Manager, izinkan "Pasang aplikasi dari sumber ini".

## 3. Pengaturan pertama kali (HyperOS / POCO)

1. Buka aplikasi, tekan **Mulai Terjemahkan**, baca penjelasan izin, lalu **Saya mengerti, lanjut**.
2. **Tampil di atas aplikasi lain**: aktifkan untuk aplikasi ini, kembali, tekan Mulai lagi.
3. **Notifikasi**: izinkan (untuk tombol Berhenti).
4. Dialog resmi Android **tangkap layar**: pilih **Seluruh layar** (jangan "Satu aplikasi"), lalu mulai.
5. Agar tidak dimatikan sistem: **Info aplikasi → Penghemat baterai → Tanpa batasan**, dan aktifkan **Mulai otomatis**. Di HyperOS, aktifkan juga "Tampilkan jendela pop-up saat berjalan di latar belakang" bila ada.
6. Sekali saja, sambil online, tekan **Unduh model bahasa (offline)** di layar utama. Setelah itu terjemahan berjalan tanpa internet.
7. (Opsional) Aksesibilitas: **Pengaturan → Aksesibilitas → Pemicu Pemindaian Layar**. Bila Android memblokir ("Pengaturan dibatasi"), buka **Info aplikasi → ⋮ → Izinkan pengaturan terbatas** lalu ulangi.

## 4. Cara memakai

1. Pilih **Bahasa sumber** (Otomatis, atau pilih bahasa tertentu agar lebih akurat) dan **Mode**.
2. Tekan **Mulai Terjemahkan**. Aplikasi pindah ke latar belakang dan tombol bulat **ON/OFF** muncul di layar.
3. Buka aplikasi atau game yang ingin diterjemahkan. Terjemahan muncul otomatis dan diperbarui saat layar berubah.
4. Tombol melayang: **ketuk** = ON/OFF, **seret** = pindah posisi, **tekan lama** = buka aplikasi.
5. **Berhenti**: tombol *Hentikan Terjemahan* di aplikasi, tombol *Berhenti* di notifikasi, atau hentikan lewat dialog sistem Android.

**Mode Game**: resolusi tangkap lebih kecil (maks. sisi 1280 px), polling lambat, hanya memindai bila ≥3% layar berubah dan sudah stabil, jeda minimum 1,8 dtk, maks. 12 blok teks. **Mode Aplikasi**: lebih sensitif dan cepat, maks. 30 blok.

**Pengaturan Overlay**: posisi (di atas teks asli / panel atas / panel bawah), ukuran teks, warna teks, warna latar, transparansi latar, dan pilihan mesin terjemahan, dengan pratinjau langsung.

## 5. Keamanan dan privasi

- Tangkap layar memakai dialog izin resmi Android (MediaProjection); izin overlay lewat pengaturan sistem.
- Gambar layar hanya diproses di memori dan tidak disimpan atau dikirim. Tanpa internet pun OCR dan terjemahan tetap berjalan (setelah model diunduh).
- Satu-satunya data yang bisa keluar HP: teks hasil OCR, hanya bila Anda memilih mesin "Server LibreTranslate sendiri". Default-nya offline.
- Layanan Aksesibilitas bersifat opsional, `canRetrieveWindowContent=false` (tidak membaca isi layar).
- Berhenti kapan saja lewat 3 cara di atas.

## 6. Struktur kode

| Berkas | Fungsi |
|---|---|
| `MainActivity.kt` | UI Compose: halaman utama, Pengaturan Overlay, alur izin |
| `CaptureService.kt` | Foreground service, MediaProjection, loop deteksi perubahan, OCR, tampilkan hasil |
| `OverlayController.kt` | Tombol melayang yang bisa dipindah + lapisan terjemahan |
| `OcrEngine.kt` | ML Kit OCR (Latin, Mandarin, Jepang, Korea, Devanagari; mode otomatis) |
| `Pipeline.kt` | OCR → deteksi bahasa → cache → terjemahan |
| `Translator.kt` | `TextTranslator` (bisa diganti), ML Kit offline, LibreTranslate, cache LRU |
| `FrameUtils.kt` | Tanda tangan frame untuk deteksi perubahan, konversi bitmap |
| `ScreenAccessibilityService.kt` | Pemicu pemindaian ulang (opsional) |

**Mengganti mesin terjemahan**: buat kelas yang mengimplementasikan `TextTranslator` (fungsi `translate(text, source, target)`), tambahkan nilai di `enum Engine`, lalu daftarkan di `TranslationPipeline.translator()`.

## 7. Batasan yang perlu diketahui

- OCR ML Kit hanya mendukung aksara Latin, Mandarin, Jepang, Korea, dan Devanagari. Rusia (Kiril), Arab, dan Thai belum bisa dibaca.
- Mode "Otomatis" itu best-effort; untuk game satu bahasa, pilih bahasa sumbernya langsung agar lebih cepat dan akurat.
- Saat memindai ulang, terjemahan disembunyikan sekitar 0,2 detik agar OCR tidak membaca terjemahannya sendiri; kedipan singkat ini normal.
- Aplikasi yang memblokir tangkap layar (FLAG_SECURE, misalnya perbankan atau video DRM) tampil hitam dan tidak bisa diterjemahkan.
- Terjemahan notifikasi: notifikasi yang tampil di layar (heads-up atau panel) ikut terbaca karena OCR membaca seluruh layar.
- Pertama kali memakai sebuah bahasa, butuh internet sekali untuk mengunduh model terjemahan (±30 MB per bahasa).
- Kualitas terjemahan mengikuti ML Kit; teks stylized/artistik di game bisa gagal dibaca OCR.
- Kode ini ditulis tanpa dapat dikompilasi di lingkungan penyusunnya. Bila Gradle melaporkan error, kirimkan pesannya agar bisa diperbaiki.
