package id.screentranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.WindowManager
import android.widget.Toast
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private class ScanConfig(
    val pollMs: Long, val settleMs: Long, val maxWaitMs: Long, val minIntervalMs: Long,
    val threshold: Float, val maxBlocks: Int, val maxSide: Int
)

// Mode Game: polling lambat, ambang perubahan tinggi, resolusi tangkap kecil, sedikit blok -> ringan.
private val GAME = ScanConfig(350, 500, 2500, 1800, 0.03f, 12, 1280)
private val APP = ScanConfig(250, 350, 1500, 900, 0.008f, 30, 1920)

class CaptureService : Service() {

    companion object {
        const val ACTION_START = "id.screentranslator.START"
        const val ACTION_STOP = "id.screentranslator.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "capture"
        private const val NOTIF_ID = 1

        val running = MutableStateFlow(false)
        val status = MutableStateFlow("Belum aktif")

        @Volatile private var rescanAt = 0L
        fun requestRescan() { rescanAt = SystemClock.elapsedRealtime() }
    }

    private lateinit var settings: AppSettings
    private lateinit var thread: HandlerThread
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayController? = null
    private var pipeline: TranslationPipeline? = null

    private var screenW = 0; private var screenH = 0
    private var capW = 0; private var capH = 0
    private var lastSig: ByteArray? = null
    private var pending: Bitmap? = null   // frame terbaru yang berubah
    private var clean: Bitmap? = null     // frame terakhir tanpa overlay
    private var lastToast: String? = null

    override fun onCreate() {
        super.onCreate()
        settings = AppSettings(this)
        thread = HandlerThread("capture").also { it.start() }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Penerjemah layar", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                // Wajib: startForeground (tipe mediaProjection) SEBELUM getMediaProjection di Android 14+.
                startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
                if (!running.value) startCapture(intent)
            }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CaptureService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Penerjemah layar aktif")
            .setContentText("Layar dibaca hanya di perangkat ini. Ketuk untuk membuka aplikasi.")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_notif), "Berhenti", stop).build())
            .build()
    }

    private fun startCapture(intent: Intent) {
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        if (data == null) { stopSelf(); return }
        val mp = try {
            getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        } catch (e: Exception) { null }
        if (mp == null) { status.value = "Izin tangkap layar tidak valid"; stopSelf(); return }
        projection = mp
        // Android 14+: callback wajib didaftarkan sebelum membuat VirtualDisplay.
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, Handler(thread.looper))

        val b = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        screenW = b.width(); screenH = b.height()
        createDisplay(mp)

        try {
            overlay = OverlayController(this, settings, onToggle = { toggle() }, onOpenApp = { openApp() }).also { it.show() }
        } catch (e: Exception) {
            status.value = "Izin 'tampil di atas aplikasi lain' belum aktif"
            stopSelf(); return
        }
        pipeline = TranslationPipeline(settings)
        running.value = true
        status.value = if (settings.enabled) "Aktif – membuka layar..." else "Dijeda (OFF)"
        job = scope.launch { scanLoop() }
    }

    private fun toggle() {
        val on = !settings.enabled
        settings.enabled = on
        overlay?.setEnabledVisual(on)
        if (on) { status.value = "Aktif"; requestRescan() } else { overlay?.clear(); status.value = "Dijeda (OFF)" }
    }

    private fun openApp() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- Penangkapan layar ----------

    private fun captureSize(): Pair<Int, Int> {
        val cfg = if (settings.mode == Mode.GAME) GAME else APP
        val s = min(1f, cfg.maxSide.toFloat() / max(screenW, screenH))
        return max(2, (screenW * s).roundToInt()) to max(2, (screenH * s).roundToInt())
    }

    private fun createDisplay(mp: MediaProjection) {
        val (w, h) = captureSize()
        capW = w; capH = h
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        display = mp.createVirtualDisplay(
            "ScreenTranslator", w, h, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    /** Menangani rotasi layar & pergantian mode (resolusi tangkap berubah). */
    private fun resizeIfNeeded() {
        val b = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        screenW = b.width(); screenH = b.height()
        val (w, h) = captureSize()
        if (w == capW && h == capH) return
        val nr = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        display?.resize(w, h, resources.displayMetrics.densityDpi)
        display?.surface = nr.surface
        reader?.close()
        reader = nr
        capW = w; capH = h
        lastSig = null
    }

    private fun screenOn() = getSystemService(PowerManager::class.java).isInteractive

    private suspend fun <T> onMain(block: () -> T): T = withContext(Dispatchers.Main) { block() }

    /** Loop utama: deteksi perubahan -> tunggu layar stabil -> OCR + terjemah -> tampilkan. */
    private suspend fun scanLoop() {
        var dirty = false
        var firstDirty = 0L
        var lastChange = 0L
        var lastScan = 0L
        var quietUntil = 0L

        while (currentCoroutineContext().isActive) {
            val cfg = if (settings.mode == Mode.GAME) GAME else APP
            delay(cfg.pollMs)
            if (!settings.enabled || !screenOn()) continue
            val now = SystemClock.elapsedRealtime()
            resizeIfNeeded()

            val ra = rescanAt
            if (ra != 0L) {
                rescanAt = 0L
                if (!dirty) { dirty = true; firstDirty = now }
                lastChange = ra
            }

            // Layar statis tidak menghasilkan frame baru -> acquireLatestImage() null -> tidak ada kerja.
            val img = try { reader?.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) {
                try {
                    val sig = FrameUtils.signature(img)
                    val prev = lastSig
                    if (now < quietUntil) {
                        lastSig = sig   // frame akibat overlay kita sendiri: jadikan acuan baru
                    } else if (prev == null || FrameUtils.changedRatio(prev, sig) > cfg.threshold) {
                        lastSig = sig
                        if (!dirty) { dirty = true; firstDirty = now }
                        lastChange = now
                        pending?.recycle()
                        pending = FrameUtils.toBitmap(img)
                    }
                } finally {
                    img.close()
                }
            }

            if (!dirty) continue
            val settled = now - lastChange >= cfg.settleMs
            val timedOut = now - firstDirty >= cfg.maxWaitMs
            if ((settled || timedOut) && now - lastScan >= cfg.minIntervalMs) {
                dirty = false
                runScan(cfg)
                lastScan = SystemClock.elapsedRealtime()
                quietUntil = lastScan + 350
            }
        }
    }

    private suspend fun grabFrame(): Bitmap? {
        repeat(6) {
            val img = try { reader?.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) {
                try { return FrameUtils.toBitmap(img) } finally { img.close() }
            }
            delay(70)
        }
        return null
    }

    private suspend fun runScan(cfg: ScanConfig) {
        val ov = overlay ?: return
        val p = pipeline ?: return
        val hadOverlay = ov.hasContent

        val src: Bitmap? = if (hadOverlay) {
            onMain { ov.setLayerVisible(false) }
            delay(170)                       // beri waktu compositor menggambar layar tanpa overlay
            grabFrame()
        } else {
            pending ?: clean
        }
        if (src == null) {
            if (hadOverlay) onMain { ov.setLayerVisible(true) }
            return
        }
        if (src !== pending) pending?.recycle()
        pending = null
        if (src !== clean) { clean?.recycle(); clean = src }

        val items = try {
            p.process(src, cfg.maxBlocks)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            status.value = "Gagal membaca layar: ${e.message ?: e.javaClass.simpleName}"
            null
        }

        val sx = screenW.toFloat() / src.width
        val sy = screenH.toFloat() / src.height
        onMain {
            if (items != null) {
                ov.render(items.map {
                    it.copy(rect = Rect((it.rect.left * sx).toInt(), (it.rect.top * sy).toInt(),
                        (it.rect.right * sx).toInt(), (it.rect.bottom * sy).toInt()))
                })
            }
            ov.setLayerVisible(true)
        }

        val err = p.lastError
        if (err != null) {
            status.value = err
            if (err != lastToast) {
                lastToast = err
                main.post { Toast.makeText(this, err, Toast.LENGTH_LONG).show() }
            }
        } else if (items != null) {
            lastToast = null
            status.value = if (items.isEmpty()) "Aktif – tidak ada teks asing terdeteksi" else "Aktif – ${items.size} teks diterjemahkan"
        }
    }

    override fun onDestroy() {
        running.value = false
        status.value = "Belum aktif"
        job?.cancel()
        scope.cancel()
        overlay?.hide()
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        pipeline?.close()
        pending?.recycle(); clean?.recycle()
        thread.quitSafely()
        super.onDestroy()
    }
}
